package ai.mas;

import java.util.ArrayList;

public class Condition {

    State state;
    Proposition proposition;

    public Condition(State state){
        this.state = state;
    }

    public Condition(State state, Proposition p){
        this.state = state;
        this.proposition = p;
    }

    public void AddProposition(Proposition p){
        this.proposition = p;
    }
}

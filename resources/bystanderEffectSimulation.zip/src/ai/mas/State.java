package ai.mas;

import java.util.ArrayList;

public class State {

    String name;
    State state;
    ActionState action;
    ArrayList<Relation> relations;

    public State(String name){
        this.name = name;
        relations = new ArrayList<>();
    }

    public State(String name, State state, ActionState action){
        this.name = name;
        this.state = state;
        this.action = action;
        relations = new ArrayList<>();
    }

    public void SetState(State state){
        this.state = state;
    }

    public void SetAction(ActionState action){
        this.action = action;
    }

    public void AddRelation(Agent agent, State state_to){
        if (!HasRelation(agent, state_to)) {
            relations.add(new Relation(agent, state_to));
        }
    }

    public void AddRelation(ArrayList<Relation> newRelations){
        for (Relation r: newRelations){
            AddRelation(r.agent, r.state_to);
        }
    }

    public boolean HasRelation(Agent agent, State to){
        for (Relation r: relations){
            if (r.agent==agent && r.state_to == to){
                return true;
            }
        }
        return false;
    }

    public boolean checkIfPredecessor(State s){
        // base case
        if (state == null){
            return false;
        } else if (state == s){
            return true;
        }
        //recursive case
        return state.checkIfPredecessor(s);
    }
}

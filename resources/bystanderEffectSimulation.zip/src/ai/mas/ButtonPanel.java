package ai.mas;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ButtonPanel extends JPanel implements ActionListener, ChangeListener, ItemListener {

    Simulation sim;
    JButton step;
    JButton reset;
    JCheckBox introspectionBox;
    JCheckBox actionNegationBox;
    JCheckBox friendshipBox;
    JLabel title;
    private Dimension buttonSize = new Dimension(75,25);

    public ButtonPanel(Simulation sim, Dimension dim){
        this.sim = sim;
        this.setPreferredSize(dim);

        // title
        title = new JLabel("Control Panel");
        Font f = title.getFont();
        title.setFont(f.deriveFont(f.getStyle() | Font.BOLD));
        add(title);

        JSeparator sep = new JSeparator();
        sep.setPreferredSize(new Dimension(dim.width-30, 10));
        sep.setVisible(true);
        add(sep);

        // step button
        step = new JButton("Start");
        step.setActionCommand("step");
        step.addActionListener(this);
        step.setPreferredSize(buttonSize);
        step.setToolTipText("Advance the simulation a single time step");

        // reset button
        reset = new JButton("Reset");
        reset.setActionCommand("reset");
        reset.addActionListener(this);
        reset.setPreferredSize(buttonSize);
        reset.setToolTipText("Reset the simulation");
        reset.setEnabled(false);

        JPanel buttons = new JPanel();
        buttons.setPreferredSize(new Dimension(dim.width-10, reset.getHeight()+30));
        buttons.add(step);
        buttons.add(reset);
        add(buttons);

        JSeparator sep1 = new JSeparator();
        sep1.setPreferredSize(new Dimension(dim.width-30, 10));
        sep1.setVisible(true);
        add(sep1);

        // num agents slider
        JPanel numAgentsPanel = new JPanel();
        JLabel numAgentsLabel = new JLabel("Number of agents:");
        numAgentsPanel.add(numAgentsLabel);
        JSlider numAgentsSlider = new JSlider(JSlider.HORIZONTAL,3,4, sim.n_agents);
        numAgentsSlider.setName("numAgents");
        numAgentsSlider.addChangeListener(this);
        numAgentsSlider.setMajorTickSpacing(1);
        numAgentsSlider.setPaintTicks(true);
        numAgentsSlider.setPaintLabels(true);
        numAgentsSlider.setSnapToTicks(true);
        numAgentsPanel.add(numAgentsSlider);
        add(numAgentsPanel);

        // checkboxes
        introspectionBox = new JCheckBox("Show introspective beliefs");
        introspectionBox.setSelected(sim.getShowIntrospectiveBeliefs());
        introspectionBox.addItemListener(this);
        JPanel iBoxPanel = new JPanel();
        iBoxPanel.setPreferredSize(new Dimension(dim.width-10, introspectionBox.getHeight()+20));
        iBoxPanel.setLayout(new BorderLayout());
        iBoxPanel.add(introspectionBox, BorderLayout.WEST);

        actionNegationBox = new JCheckBox("Show beliefs about negated actions");
        actionNegationBox.setSelected(sim.getShowNegatedActionBeliefs());
        actionNegationBox.addItemListener(this);
        JPanel nBoxPanel = new JPanel();
        nBoxPanel.setPreferredSize(new Dimension(dim.width-10, actionNegationBox.getHeight()+20));
        nBoxPanel.setLayout(new BorderLayout());
        nBoxPanel.add(actionNegationBox, BorderLayout.WEST);

        friendshipBox = new JCheckBox("Friendship tie between agent 0 and agent 1");
        friendshipBox.setSelected(sim.getUseFriendship());
        friendshipBox.addItemListener(this);
        JPanel fBoxPanel = new JPanel();
        fBoxPanel.setPreferredSize(new Dimension(dim.width-10, actionNegationBox.getHeight()+20));
        fBoxPanel.setLayout(new BorderLayout());
        fBoxPanel.add(friendshipBox, BorderLayout.WEST);
        add(fBoxPanel);
        JSeparator sep2 = new JSeparator();
        sep2.setPreferredSize(new Dimension(dim.width-30, 10));
        sep2.setVisible(true);
        add(sep2);
        add(iBoxPanel);
        add(nBoxPanel);
    }

    public void Update(){
        if (sim.state == Simulation.SimState.INIT) {
            step.setText("Start");
            step.setEnabled(true);
            reset.setEnabled(false);
        } else {
            step.setText("Step");
            reset.setEnabled(true);
        }
        if (sim.state == Simulation.SimState.FINAL){
            step.setEnabled(false);
        }
    }

    @Override
    public void actionPerformed(ActionEvent a){
        if("step".equals(a.getActionCommand())){
            sim.Step();
        }
        if("reset".equals(a.getActionCommand())){
            sim.Reset();
        }
    }

    @Override
    public void stateChanged(ChangeEvent a){
        JSlider source = (JSlider)a.getSource();
        String name = source.getName();

        if("numAgents".equals(name)) {
//            stop();
            sim.n_agents = source.getValue();
            sim.Reset();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getItemSelectable();
        if (source == introspectionBox){
            sim.setShowIntrospectiveBeliefs(introspectionBox.isSelected());
        }

        if (source == actionNegationBox){
            sim.setShowNegatedActionBeliefs(actionNegationBox.isSelected());
        }

        if (source == friendshipBox){
            sim.setUseFriendship(friendshipBox.isSelected());
        }
    }

}

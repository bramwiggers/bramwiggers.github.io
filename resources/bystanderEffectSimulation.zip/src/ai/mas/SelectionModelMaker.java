package ai.mas;

import javax.swing.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

import static java.lang.System.exit;

public class SelectionModelMaker {

    Simulation sim;

    public SelectionModelMaker(Simulation sim){
        this.sim = sim;
    }

    public ActionModel Build() {

        ArrayList<ActionModel> modelsPerAgent = new ArrayList<>();
        for (int i=0; i<sim.n_agents; i++){
            switch (sim.agents.get(i).ChooseAction()){
                case 'I':
                    modelsPerAgent.add(BuildGamma(sim.pIntervene.get(i)));
//                    System.out.println(String.format("Agent %s intervenes", i));
                    break;
                case 'O':
                    modelsPerAgent.add(BuildDelta(sim.pEvade.get(i), sim.pObserve.get(i), i, true));
//                    System.out.println(String.format("Agent %s observes", i));
                    break;
                case 'E':
                    modelsPerAgent.add(BuildDelta(sim.pEvade.get(i), sim.pObserve.get(i), i, false));
//                    System.out.println(String.format("Agent %s evades", i));
                    break;
            }
        }

        // get cartesian product
        ActionModel product = new ActionModel(sim);
        product.AddState(new ActionState("s"), true);
        for (int i=0; i<sim.n_agents; i++){
            product = CartesianProduct(product, modelsPerAgent.get(i));
        }

        // add preconditions
        for (ActionState s: product.actionStates){
            s.SetPrecondition(sim.model.GetTruthProposition());
            s.AddPostCondition(sim.model.GetTruthProposition());
        }

        return product;
    }

    private ActionModel BuildGamma(Proposition i){
        ActionModel g = new ActionModel(sim);
//        g.AddState(new ActionState("I"));
        ActionState s = new ActionState("I");
        s.AddPostCondition(i);
        g.AddState(s, true);
        g.MakeReflexive();
        return g;
    }

    private ActionModel BuildDelta(Proposition e, Proposition o, int agent, boolean action_is_observe){
        ActionModel d = new ActionModel(sim);
        ActionState s = new ActionState("O"+agent);
        s.AddPostCondition(o);
//        o.AddState(d, s);
        ActionState t = new ActionState("E"+agent);
        t.AddPostCondition(e);
//        e.AddState(d, t);
        for (int i=0; i<sim.n_agents; i++){
            if (i!=agent && !sim.agents.get(agent).friends.contains(sim.agents.get(i))){
                s.AddRelation(sim.agents.get(i), t);
            }
        }
        d.AddState(s, action_is_observe);
        d.AddState(t, !action_is_observe);
        d.MakeReflexive();
        return d;
    }

    private ActionModel CartesianProduct(ActionModel a, ActionModel b){
        ActionModel product = new ActionModel(sim);
        ArrayList<StatePair> pairs = new ArrayList<>();
        int cnt = 0;
        for (ActionState s: a.actionStates){
            for (ActionState s2: b.actionStates){
                pairs.add(new StatePair(s, s2));
                ActionState sNew = new ActionState("s"+cnt);
                cnt++;
                sNew.AddPostCondition(s.postConditions);
                sNew.AddPostCondition(s2.postConditions);
                boolean isTrueState = (a.trueState == s && b.trueState == s2);
                product.AddState(sNew, isTrueState);
            }
        }
        for (int i=0; i<pairs.size(); i++){
            for (int j=0; j<pairs.size(); j++){
                StatePair u = pairs.get(i);
                StatePair v = pairs.get(j);
                // add relations
                for (Agent agent: sim.agents){
                    if (CheckRelations(agent, u, v)){
                        product.actionStates.get(i).AddRelation(agent, product.actionStates.get(j));
                    }
                }
            }
        }
        product.MakeTransitive();
        product.MakeReflexive();
        return product;
    }

    private boolean CheckRelations(Agent agent, StatePair u, StatePair v){
        if (u.actionState1 == v.actionState1){
            for (Relation r: u.actionState2.relations){
                if (r.agent == agent && r.state_to == v.actionState2){
                    return true;
                }
            }
        }
        if (u.actionState2 == v.actionState2){
            for (Relation r: u.actionState1.relations){
                if (r.agent==agent && r.state_to == v.actionState1){
                    return true;
                }
            }
        }
        return false;
    }

}

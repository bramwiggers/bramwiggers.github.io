package ai.mas;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class KnowledgePanel extends JPanel {

    Simulation sim;
    JTextArea infoPane;
    JScrollPane scrollPane;
    JLabel title;
//    int current_agent = 0;

    public KnowledgePanel(Simulation sim, ArrayList<Agent> agents){
        this.sim = sim;
//        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(200, 300));
        setBackground(Color.darkGray);
        setOpaque(true);
        title = new JLabel("Beliefs");
        Font f = title.getFont();
        title.setFont(f.deriveFont(f.getStyle() | Font.BOLD));
        title.setForeground(Color.white);
        add(title);
        infoPane = new JTextArea();
        infoPane.setOpaque(false);
        infoPane.setEditable(false);
        infoPane.setVisible(true);
        infoPane.setLineWrap(true);
        infoPane.setWrapStyleWord(true);
        scrollPane = new JScrollPane(infoPane);
        scrollPane.setPreferredSize(new Dimension(200-20,300-35));
//        scrollPane.setOpaque(false);
        scrollPane.setVisible(true);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane);
        Update();
    }

    private void write_beliefs(int agent_idx){
        Agent agent = sim.agents.get(agent_idx);
        title.setText(String.format("Beliefs agent %s", agent.name));
        ArrayList<Belief> beliefs = agent.ListBeliefs(sim.model, sim.model.trueState);
        for (Belief b: beliefs) {
            infoPane.append(b+"\n");
        }
//        current_agent = agent_idx;
        scrollPane.getVerticalScrollBar().setValue(0);
    }

    public void Update(){
        title.setText("Beliefs");
        infoPane.setText(null);
        if (sim.state != Simulation.SimState.INIT) {
            int current_agent = sim.situationPanel.getActive_agent();
            write_beliefs(current_agent);
        }
    }
}

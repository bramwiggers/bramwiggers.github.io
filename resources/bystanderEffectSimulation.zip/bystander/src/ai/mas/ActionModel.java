package ai.mas;

import java.util.ArrayList;

import static java.lang.System.exit;

public class ActionModel extends Model {

    ArrayList<ActionState> actionStates;

    public ActionModel(Simulation sim){
        super(sim);
        actionStates = new ArrayList<>();
    }

    public void AddState(ActionState state){
        AddState(state, false);
    }

    public void AddState(ActionState state, boolean isTrueState){
        actionStates.add(state);
        if (isTrueState) {
            trueState = state;
        }
    }

    public void MakeReflexive(){
        for (State s: actionStates){
            for (Agent a: sim.agents){
                if (!s.HasRelation(a, s)) {
                    s.AddRelation(a, s);
                }
            }
        }
    }

    public void MakeTransitive(){
        for (State s: actionStates){
            ArrayList<Relation> newRelations = new ArrayList<>();
            for (Relation r: s.relations){
                for (Relation r2: r.state_to.relations){
                    if (r.agent == r2.agent && s!=r2.state_to){
                        newRelations.add(new Relation(r.agent, r2.state_to));
                    }
                }
            }
            s.AddRelation(newRelations);
        }
    }

    public Proposition GetTruthProposition(){
        Proposition truth = new Proposition("truth");
        truth.AddValuation(this);
        for (State s: actionStates){
            truth.AddState(this, s);
        }
        return truth;
    }

    public Proposition GetNegation(Proposition p){
        Proposition pNeg = new Proposition(p.name);
        pNeg.AddValuation(this);
        pNeg.GetStates(this).addAll(this.actionStates);
        pNeg.GetStates(this).removeAll(p.GetStates(this));
        return pNeg;
    }

    public Proposition GetConjunction(Proposition p, Proposition q){
        Proposition pCon = new Proposition(p.name+"&"+q.name);
        pCon.AddValuation(this);
        pCon.GetStates(this).addAll(p.GetStates(this));
        pCon.GetStates(this).retainAll(q.GetStates(this));
        return pCon;
    }

    public void SetTrueState(State s){
        if (!actionStates.contains(s)){
            System.out.println("ERROR: Cannot set true state, because state not in model");
            exit(0);
        }
        trueState = s;
    }
}

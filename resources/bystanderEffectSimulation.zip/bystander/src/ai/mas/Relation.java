package ai.mas;

public class Relation {

    Agent agent;
    State state_to;

    public Relation(Agent agent, State state_to){
        this.agent = agent;
        this.state_to = state_to;
    }
}

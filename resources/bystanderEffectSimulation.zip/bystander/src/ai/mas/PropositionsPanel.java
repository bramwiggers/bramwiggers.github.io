package ai.mas;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class PropositionsPanel extends JPanel {

    Simulation sim;
    JLabel title;
    JTextArea propositionPane;
    JTable table;
    DefaultTableModel model;

    public PropositionsPanel(Simulation sim, Dimension dim){
        this.sim = sim;
        this.setPreferredSize(dim);
        setBackground(Color.darkGray);
        title = new JLabel("Propositions");
        Font f = title.getFont();
        title.setFont(f.deriveFont(f.getStyle() | Font.BOLD));
        title.setForeground(Color.white);
        add(title);

        model = new DefaultTableModel();
        table = new JTable(model);

        model.addColumn("Proposition");
        model.addColumn("Description");
        model.addColumn("Valuation in real state");

        JScrollPane tablePane = new JScrollPane(table);
        tablePane.setPreferredSize(new Dimension(this.getPreferredSize().width-20,this.getPreferredSize().height-35));
        table.setCellSelectionEnabled(false);
        table.setColumnSelectionAllowed(false);
        table.setFocusable(false);
        table.setDragEnabled(false);
        table.setRowSelectionAllowed(false);
//        table.setShowGrid(false);
        table.setEnabled(false);
        table.setOpaque(false);
        ((DefaultTableCellRenderer)table.getDefaultRenderer(Object.class)).setOpaque(false);
        table.getTableHeader().setReorderingAllowed(false);

        tablePane.setOpaque(false);
//        tablePane.getViewport().setOpaque(false);
        add(tablePane);
//        Update();
    }

    public void Update(){
        model.setRowCount(0);
        if (sim.state != Simulation.SimState.INIT) {
            for (Proposition p : sim.model.propositions) {
                model.addRow(new Object[]{p.name, p.description, p.GetStates(sim.model).contains(sim.model.trueState)});
            }
        }
    }
}

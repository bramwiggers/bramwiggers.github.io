package ai.mas;

import java.util.ArrayList;

public class ActionState extends State {

    Proposition pre;
    ArrayList<Proposition> postConditions;

    public ActionState(String name){
        super(name);
        postConditions = new ArrayList<>();
    }

    public ActionState(String name, Proposition pre, Proposition post){
        super(name);
        this.pre = pre;
    }

    public void SetPrecondition(Proposition pre){
        this.pre = pre;
    }

    public void SetPostcondition(Proposition post){
//        this.post = post;
    }

    public void AddPostCondition(Proposition p){
        postConditions.add(p);
    }

    public void AddPostCondition(ArrayList<Proposition> propositions){
        for (Proposition p: propositions) {
            postConditions.add(p);
        }
    }
}

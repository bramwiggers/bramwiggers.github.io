package ai.mas;

import java.lang.reflect.Array;
import java.util.ArrayList;

import static java.lang.System.exit;

public class ChooseActionModel extends ActionModel {

    public ChooseActionModel(Simulation sim){
        super(sim);
        Build();
        FindTrueState();
    }

    private void FindTrueState(){
        // list of propositions that should be true in true state
//        ArrayList<Proposition> propositions = new ArrayList<>();
        Proposition p = GetTruthProposition();
        for (int i=0; i<sim.n_agents; i++) {
            Agent a = sim.agents.get(i);
            switch (a.ChooseAction()){
                case 'I':
                    p = GetConjunction(p, sim.pIntervene.get(i));
                    System.out.println(String.format("agent %s intervenes", a.name));
                    break;
                case 'E':
                    p = GetConjunction(p, sim.pEvade.get(i));
                    System.out.println(String.format("agent %s evades", a.name));
                    break;
                case 'O':
                    p = GetConjunction(p, sim.pObserve.get(i));
                    System.out.println(String.format("agent %s observes", a.name));
                    break;
            }
        }

        // find true state in model
        if (p.GetStates(this).size()!=1){
            System.out.println("ERROR: More than 1 true state found");
            exit(0);
        }
        SetTrueState(p.GetStates(this).get(0));
    }

    private void Build(){

        for (int i=0; i<sim.n_agents; i++){
            Proposition o = sim.pObserve.get(i);
            Proposition e = sim.pEvade.get(i);
            Proposition I = sim.pIntervene.get(i);
            o.AddValuation(this);
            e.AddValuation(this);
            I.AddValuation(this);
            AddProposition(o);
            AddProposition(e);
            AddProposition(I);
        }

        int n = sim.agents.size();

        ArrayList<Integer> in = new ArrayList<>();
        ArrayList<Integer> ni = new ArrayList<>();
        for (int i=0; i<sim.n_agents; i++) {
            Agent a = sim.agents.get(i);
            if (a.ChooseAction() == 'I'){
                in.add(i);
            } else {
                ni.add(i);
            }
        }
        System.out.println(in.size());
        System.out.println(ni.size());
        MakeStates(in, ni);

        // add relations
        for (ActionState s: actionStates){
            for (ActionState s2: actionStates){
                for (int i=0; i<sim.agents.size(); i++){
                    if ((sim.pObserve.get(i).GetStates(this).contains(s) && sim.pObserve.get(i).GetStates(this).contains(s2)) ||
                            (sim.pEvade.get(i).GetStates(this).contains(s) && sim.pEvade.get(i).GetStates(this).contains(s2))){
                        // if n Es in s larger than in s2 -> add relation s to s2
                        int nEs1 = 0;
                        int nEs2 = 0;
                        for (int j=0; j<sim.n_agents; j++){
                            if (sim.pEvade.get(j).GetStates(this).contains(s)){
                                nEs1++;
                            }
                            if (sim.pEvade.get(j).GetStates(this).contains(s2)){
                                nEs2++;
                            }
                        }
                        if (nEs2 > nEs1 || nEs2 == nEs1){
                            s.AddRelation(sim.agents.get(i), s2);
                        }
                    }
                }
            }
        }
        MakeTransitive();
        MakeReflexive();
    }

    private void MakeStates(ArrayList<Integer> in, ArrayList<Integer> ni){

        for (int i = 0; i < (1<<ni.size()); i++)
        {
            ActionState sigma = new ActionState("sigma"+i);
            sigma.SetPrecondition(sim.model.GetTruthProposition());
            sigma.AddPostCondition(sim.model.GetTruthProposition());

            AddState(sigma);

            for (int k=0; k<in.size(); k++){
                sim.pIntervene.get(in.get(k)).AddState(this, sigma);
                sigma.AddPostCondition(sim.pIntervene.get(in.get(k)));
            }

            System.out.print("{ ");
            // Print current subset
            for (int j = 0; j < ni.size(); j++)
                if ((i & (1 << j)) > 0) {
                    System.out.print(sim.agents.get(ni.get(j)) + " ");
                    sim.pEvade.get(ni.get(j)).AddState(this, sigma);
                    sigma.AddPostCondition(sim.pEvade.get(ni.get(j)));
                } else {
                    sim.pObserve.get(ni.get(j)).AddState(this, sigma);
                    sigma.AddPostCondition(sim.pObserve.get(ni.get(j)));
                }
            System.out.println("}");
        }
    }

}

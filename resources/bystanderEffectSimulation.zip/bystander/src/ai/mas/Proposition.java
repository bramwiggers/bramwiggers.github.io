package ai.mas;

import java.util.ArrayList;

public class Proposition {

//    ArrayList<State> states;
    ArrayList<Valuation> valuations;
    String name;
    String description;

    public Proposition(String name){
        this.name = name;
//        states = new ArrayList<>();
        valuations = new ArrayList<>();
    }

    public Proposition(String name, Model model){
        this.name = name;
//        states = new ArrayList<>();
        valuations = new ArrayList<>();
        valuations.add(new Valuation(model));
    }

    public boolean Agree(Model model, State state1, State state2){
        ArrayList<State> states = GetStates(model);
        return ((states.contains(state1) && states.contains(state2)) || (!states.contains(state1) && !states.contains(state2)));
    }


    public void AddState(Model model, State state){
        Valuation val = GetValuation(model);
        if (val == null){
            valuations.add(new Valuation(model));
        }
        GetValuation(model).AddState(state);
    }

    public ArrayList<State> GetStates(Model model){
        Valuation val = GetValuation(model);
        if (val == null){
            AddValuation(model);
        }
        return GetValuation(model).states;
    }

    public void AddValuation(Model model){
        valuations.add(new Valuation(model));
    }

    public void SetDescription(String description){
        this.description = description;
    }

    public Valuation GetValuation(Model model){
        for (Valuation val: valuations) {
            if (val.model == model){
                return val;
            }
        }
        return null;
    }

    public boolean HasValuation(Model model){
        for (Valuation v: valuations){
            if (v.model==model){
                return true;
            }
        }
        return false;
    }

    public class Valuation {

        Model model;
        ArrayList<State> states;

        Valuation(Model model){
            this.model = model;
            states = new ArrayList<>();
        }

        public void AddState(State state){
            if (!states.contains(state)) {
                states.add(state);
            }
        }

        public boolean Agree(State state1, State state2){
            return ((states.contains(state1) && states.contains(state2)) || (!states.contains(state1) && !states.contains(state2)));
        }
    }
}
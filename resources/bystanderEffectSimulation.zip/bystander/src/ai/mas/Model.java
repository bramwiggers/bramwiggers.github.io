package ai.mas;

import java.util.ArrayList;

import static java.lang.System.exit;

public class Model {

    ArrayList<State> states;
    ArrayList<Proposition> propositions;
    State trueState;
    Simulation sim;

    public Model(Simulation sim){
        states = new ArrayList<>();
        propositions = new ArrayList<>();
        this.sim = sim;
    }

    public void AddState(State state){
        AddState(state, false);
    }

    public void AddState(State state, boolean isTrueState){
        states.add(state);
        if (isTrueState) {
            trueState = state;
        }
    }

    public void MakeReflexive(){
        for (State s: states){
            for (Agent a: sim.agents){
                if (!s.HasRelation(a, s)) {
                    s.AddRelation(a, s);
                }
            }
        }
    }

    public void MakeTransitive(){
        for (State s: states){
            ArrayList<Relation> newRelations = new ArrayList<>();
            for (Relation r: s.relations){
                for (Relation r2: r.state_to.relations){
                    if (r.agent == r2.agent && s!=r2.state_to){
                        newRelations.add(new Relation(r.agent, r2.state_to));
                    }
                }
            }
            s.AddRelation(newRelations);
        }
    }

    public void AddProposition(Proposition proposition){
        if (!propositions.contains(proposition)) {
            propositions.add(proposition);
        }
    }

    public Proposition GetTruthProposition(){
        Proposition truth = new Proposition("truth");
        truth.AddValuation(this);
        for (State s: states){
            truth.AddState(this, s);
        }
        return truth;
    }

    public Proposition GetNegation(Proposition p){
        Proposition pNeg = new Proposition(p.name);
        pNeg.AddValuation(this);
        pNeg.GetStates(this).addAll(this.states);
        pNeg.GetStates(this).removeAll(p.GetStates(this));
        return pNeg;
    }

    public Proposition GetConjunction(Proposition p, Proposition q){
        Proposition pCon = new Proposition(p.name+"&"+q.name);
        pCon.AddValuation(this);
        pCon.GetStates(this).addAll(p.GetStates(this));
        pCon.GetStates(this).retainAll(q.GetStates(this));
        return pCon;
    }

    public Proposition GetDisjunction(Proposition p, Proposition q){
        Proposition pDis = new Proposition(p.name+"V"+q.name);
        pDis.AddValuation(this);
        pDis.GetStates(this).addAll(p.GetStates(this));
        pDis.GetStates(this).addAll(q.GetStates(this));
        return pDis;
    }

    public Proposition GetImplication(Proposition p, Proposition q){
        Proposition pImp = new Proposition(p.name+"->"+q.name);
        pImp.AddValuation(this);
        pImp.GetStates(this).addAll(this.states);
        pImp.GetStates(this).removeAll(p.GetStates(this));
        pImp.GetStates(this).addAll(q.GetStates(this));
        return pImp;
    }

    public Proposition GetBelief(Agent a, Proposition p){
        Proposition pBel = new Proposition("B_"+a.name+"("+p.name+")");
        pBel.AddValuation(this);
        for (State s: states){
            if (p.GetStates(this).containsAll(a.GetPlausibilityCell(this, s))){
                pBel.GetStates(this).add(s);
            }
        }
        return pBel;
    }

    public Proposition GetKnowledge(Agent a, Proposition p){
        Proposition pKno = new Proposition("K_"+a.name+"("+p.name+")");
        pKno.AddValuation(this);
        for (State s: states){
            if (p.GetStates(this).containsAll(a.GetInformationCell(this, s))){
                pKno.GetStates(this).add(s);
            }
        }
        return pKno;
    }

    public Proposition GetInterpretation(Model oldmodel, Proposition p){
//        boolean print = false;
        Proposition pNew = new Proposition("tmp");
        pNew.AddValuation(this);
        for (State s: states){
//            if (s==trueState){
//                print = true;
//            } else {
//                print = false;
//            }
            for (State s_old: oldmodel.states){
//                if (print){
//                    System.out.println("-------");
//                    System.out.println(p.states.contains(s_old));
//                    System.out.println(s.checkIfPredecessor(s_old));
//                }
                if (p.GetStates(oldmodel).contains(s_old) && s.checkIfPredecessor(s_old)){
                    pNew.AddState(this, s);
                    break;
                }
            }
        }
        return pNew;
    }

    public Proposition GetSocialBelief(Agent agent, Proposition p){
        Proposition SBp = new Proposition(p.name);
        int trueVotes = 0;
        int falseVotes = 0;
        for (State s: states) {
            double alpha = 0;
            double beta = 0;
            if (GetBelief(agent, p).GetStates(this).contains(s)){
                alpha = 0.5;
            }
            if (GetBelief(agent, GetNegation(p)).GetStates(this).contains(s)){
                beta = 0.5;
            }
            for (Agent j : sim.agents) {
                if (j!=agent){
                    if (GetBelief(agent, GetBelief(j, p)).GetStates(this).contains(s)) {
                        trueVotes++;
                    }
                    if (GetBelief(agent, GetBelief(j, GetNegation(p))).GetStates(this).contains(s)) {
                        falseVotes++;
                    }
                }
            }
            if ((trueVotes + alpha) > (falseVotes + beta)){
                SBp.AddState(this, s);
            }
        }
        return SBp;
    }

    public void Summary(){
        System.out.println(String.format("===================SUMMARY %s=================", sim.state));
        for (State s: states){
            if (s == trueState){
                System.out.println("\n" + s.name + " (true):");
            } else {
                System.out.println("\n" + s.name + ":");
            }
            System.out.println("Propositions:");
            for (Proposition p : propositions) {
                if (p.GetStates(this).contains(s)) {
                    System.out.println(p.name);
                }
            }
//            System.out.println("Relations agent 0");
//            for (Relation r : relations) {
//                if (r.agent == sim.agents.get(0) && r.state_from == s) {
//                    System.out.println(r.state_to.name);
//                }
//            }
        }
    }

    public void SetTrueState(State s){
        if (!states.contains(s)){
            System.out.println("ERROR: Cannot set true state, because state not in model");
            exit(0);
        }
        trueState = s;
    }
}

package ai.mas;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

import static java.lang.System.exit;

public class Simulation {

    JFrame frame;
    SituationPanel situationPanel;
    KnowledgePanel knowledgePanel;
    ButtonPanel buttonPanel;
    SimInfoPanel simInfoPanel;
    PropositionsPanel propositionsPanel;
    Model initialModel;
    Model eventModel;
    Model chooseActionModel;
    Model interpretationModel;
    Model finalModel;
    Model model;
    ArrayList<Agent> agents;
    Proposition pEvent;
    ArrayList<Proposition> pObserve;
    ArrayList<Proposition> pEvade;
    ArrayList<Proposition> pIntervene;
    private boolean showIntrospectiveBeliefs;
    private boolean showNegatedActionBeliefs;
    private boolean useFriendship;
    boolean intervened;

    int n_agents = 3;
    SimState state = SimState.INIT;

    public enum SimState {
        INIT, START, EVENT, CHOOSE, REVISE, CHOOSENEW, FINAL
    }

    //Constructor
    public Simulation(){

        InitSim();

        // frame
        frame = new JFrame("Bystander Effect Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER,15,10));

        // Make the panels
        situationPanel = new SituationPanel(this);
        situationPanel.setVisible(true);
        situationPanel.setBorder(BorderFactory.createLineBorder(Color.blue));

        // knowledgepanel contains the propositional knowledge of all agents
        knowledgePanel = new KnowledgePanel(this, this.agents);
        knowledgePanel.setVisible(true);
        knowledgePanel.setBorder(BorderFactory.createLineBorder(Color.lightGray));

        // buttonpanel has a button to advance the simulation to the next step
        buttonPanel = new ButtonPanel(this, new Dimension(350,300));
        buttonPanel.setVisible(true);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.lightGray));

        // siminfopanel shows the information about the current state of the simulation
        simInfoPanel = new SimInfoPanel(this, new Dimension(500,300));
        simInfoPanel.setVisible(true);
        simInfoPanel.setBorder(BorderFactory.createLineBorder(Color.lightGray));

        // propositionpanel shows the list of propositions in the current model
        propositionsPanel = new PropositionsPanel(this, new Dimension(565, 300));
        propositionsPanel.setVisible(true);
        propositionsPanel.setBorder(BorderFactory.createLineBorder(Color.lightGray));

        // add panels to frame
        frame.getContentPane().add(situationPanel);
        frame.getContentPane().add(knowledgePanel);
        frame.getContentPane().add(buttonPanel);
        frame.getContentPane().add(simInfoPanel);
        frame.getContentPane().add(propositionsPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setResizable(true);
        frame.setSize(new Dimension(1100, 650));
        frame.setResizable(false);

        this.showIntrospectiveBeliefs = false;
        this.showNegatedActionBeliefs = false;
        this.useFriendship = false;
        this.intervened = false;

    }

    private void InitSim(){
        // create agents
        agents = new ArrayList<>();
        for (int i=0; i<n_agents; i++){
            Agent a = new Agent(Integer.toString(i), Agent.AgentType.HESITATOR, this);
            agents.add(a);
        }
        if (useFriendship) {
            agents.get(0).friends.add(agents.get(1));
            agents.get(1).friends.add(agents.get(0));
        }
        this.pEvent = new Proposition("p");
        this.pEvent.SetDescription("An intervention is required");
//        this.model = initModel();
//        pEvent.AddValuation(this.model);
    }

    private void EventStep(){
        ActionModel actionmodel = MakeEventActionModel();
        this.eventModel = APU(this.model, actionmodel);
        this.model = eventModel;
    }

    private void InitModel(){
        Model model = new Model(this);
        State s = new State("s0");
        model.AddState(s, true);
        model.AddProposition(pEvent);
        model.MakeTransitive();
        model.MakeReflexive();
        pEvent.AddValuation(model);
        this.initialModel = model;
        this.model = this.initialModel;
    }

    private ActionModel MakeEventActionModel(){

        ActionModel model = new ActionModel(this);
        Proposition tmp = new Proposition("tmp");
        model.AddProposition(pEvent);

        ArrayList<Proposition> from = new ArrayList<>();
        ArrayList<Proposition> to = new ArrayList<>();
        for (int i=0; i<n_agents; i++){
            from.add(new Proposition("from"+i));
            to.add(new Proposition("to"+i));
        }

        int n = this.agents.size();

        // Run a loop for printing all 2^n
        // subsets one by obe
        for (int i = 0; i < (1<<n); i++)
        {
            ActionState sigma = new ActionState("sigma"+i);
            ActionState tau = new ActionState("tau"+i);
            sigma.SetPrecondition(this.model.GetTruthProposition());
            sigma.AddPostCondition(pEvent);
            tau.SetPrecondition(this.model.GetTruthProposition());
            tau.AddPostCondition(this.model.GetTruthProposition());
            tmp.AddState(model, sigma);
            if (i==0) {
                model.AddState(sigma, true);
            } else {
                model.AddState(sigma);
            }
            model.AddState(tau);

            System.out.print("{ ");
            // Print current subset
            for (int j = 0; j < n; j++)
                if ((i & (1 << j)) > 0){
                    sigma.AddRelation(agents.get(j), tau);
                    from.get(j).AddState(model, sigma);
                    to.get(j).AddState(model, tau);
                    System.out.print(agents.get(j) + " ");
                } else {
                    tau.AddRelation(agents.get(j), sigma);
                    from.get(j).AddState(model, tau);
                    to.get(j).AddState(model, sigma);
                }
            System.out.println("}");
        }

        for (ActionState s: model.actionStates){
            ArrayList<Relation> newRelations = new ArrayList<>();
            for (ActionState s2: model.actionStates) {
                for (int i = 0; i < n_agents; i++) {
                    if (tmp.Agree(model, s, s2)) {
                        if (from.get(i).GetStates(model).contains(s) && from.get(i).GetStates(model).contains(s2)) {
                            newRelations.add(new Relation(agents.get(i), s2));
                        }
                        if (to.get(i).GetStates(model).contains(s) && to.get(i).GetStates(model).contains(s2)) {
                            newRelations.add(new Relation(agents.get(i), s2));
                        }
                    }
                }
            }
            s.AddRelation(newRelations);
        }

        model.MakeTransitive();
        model.MakeReflexive();
        return model;
    }

    private void ChooseActionStep(){
        if (pEvade==null) {
            MakeActionPropositions();
        }

//        ChooseActionModel model = new ChooseActionModel(this);
        ActionSelectionModel maker = new ActionSelectionModel(this);
        ActionModel model = maker.Build();
        this.chooseActionModel = APU(this.model, model);
        this.model = this.chooseActionModel;
        System.out.println("=======================PROPOSITIONS IN TRUE STATE:");
        for (Proposition p: this.model.propositions){
            if (p.GetStates(this.model).contains(this.model.trueState)){
                System.out.println(p.name);
            }
        }
//        if (state==SimState.CHOOSENEW){
//            exit(0);
//        }

//        this.model.Summary();
    }

    private void AlterBeliefsStep(){
//        for (Agent a: agents){
//            Proposition SBp = this.model.GetSocialBelief(a, pEvent);
//            a.AddBelief(this.model, this.model.trueState, SBp, true);
//            a.AddBelief(this.model, this.model.trueState, SBp, false);
//        }
    }

    private void MakeActionPropositions(){
        this.pObserve = new ArrayList<>();
        this.pEvade = new ArrayList<>();
        this.pIntervene = new ArrayList<>();
        // make propositions
        for (int i=0; i<n_agents; i++){
            Proposition O = new Proposition("O"+i);
            Proposition E = new Proposition("E"+i);
            Proposition I = new Proposition("I"+i);
            O.SetDescription(String.format("Agent %s observed", i));
            E.SetDescription(String.format("Agent %s evaded", i));
            I.SetDescription(String.format("Agent %s intervened", i));
            pObserve.add(O);
            pEvade.add(E);
            pIntervene.add(I);
            this.model.AddProposition(O);
            this.model.AddProposition(E);
            this.model.AddProposition(I);
        }
    }

    private void InterpretationStep(){

        for (int i=0; i<n_agents; i++) {
            ActionModel interpretationModel = new ActionModel(this);
            ActionState rho = new ActionState("rho"+agents.get(i).name);
            Proposition E = model.GetImplication(pEvade.get(i), model.GetInterpretation(eventModel, eventModel.GetBelief(agents.get(i), eventModel.GetNegation(pEvent))));
            Proposition O = model.GetImplication(pObserve.get(i), model.GetInterpretation(eventModel,
                    eventModel.GetConjunction(eventModel.GetBelief(agents.get(i), pEvent), eventModel.GetNegation(eventModel.GetKnowledge(agents.get(i), pEvent)))));
            Proposition pre = model.GetConjunction(E, O);
            Proposition I = model.GetImplication(pIntervene.get(i), model.GetInterpretation(eventModel, eventModel.GetKnowledge(agents.get(i), pEvent)));
            pre = model.GetConjunction(pre, I);
            rho.SetPrecondition(pre);

            interpretationModel.AddState(rho, true);
            interpretationModel.MakeTransitive();
            interpretationModel.MakeReflexive();
//            for (Relation r: interpretationModel.relations){
//                System.out.println(String.format("agent %s: %s -> %s",r.agent.name, r.state_from.name, r.state_to.name));
//            }
            this.model = APU(model, interpretationModel);
        }
        this.interpretationModel = this.model;
        this.model.Summary();
    }

    private Model APU(Model model, ActionModel actionModel){
        Model product = new Model(this);
        // get state space
        for (State s: model.states){
            for (ActionState as: actionModel.actionStates){
                if (as.pre.GetStates(model).contains(s)){
                    if (s==model.trueState && as==actionModel.trueState) {
                        product.AddState(new State("s" + (product.states.size()), s, as), true);
                    } else {
                        product.AddState(new State("s" + (product.states.size()), s, as));
                    }
                }
            }
        }
        System.out.println(String.format("=========================================MADE %s NEW STATES", product.states.size()));
        // get relations
        for (int i=0; i<product.states.size(); i++){
            for (int j=0; j<product.states.size(); j++){
                State s = product.states.get(i).state;
                State t = product.states.get(j).state;
                ActionState sigma = product.states.get(i).action;
                ActionState tau = product.states.get(j).action;
                for (Agent agent: agents){
                    if (CheckPreOrder(agent, model, actionModel, s, t, sigma, tau)){
                        product.states.get(j).AddRelation(agent, product.states.get(i));
                    }
                }
            }
        }
//        System.out.println(String.format("=========================================MADE %s NEW RELATIONS", product.relations.size()));
        // get propositions
        for (Proposition p: this.model.propositions){
            for (int i=0; i<product.states.size(); i++){
                State newState = product.states.get(i);
                if(p.GetStates(this.model).contains(newState.state)){
                    boolean add = true;
                    for (Proposition post: newState.action.postConditions){
                        if (post.GetStates(this.model).equals(this.model.GetNegation(p).GetStates(this.model))){
                            add = false;
                            break;
                        }
                        // hacky attempt
                        if (post.name.length()==2 && p.name.length()==2) {
                            if (post.name.charAt(1) == p.name.charAt(1) && post.name.charAt(0) != p.name.charAt(0)) {
                                add = false;
                                break;
                            }
                        }
                    }
                    if (add) {
                        p.AddState(product, newState);
                    }
                } else {
                    for (Proposition post: newState.action.postConditions) {
                        if (post == p) {
                            p.AddState(product, newState);
                        }
                    }
                }
            }
            product.AddProposition(p);
        }
        System.out.println(String.format("=========================================MADE %s NEW PROPOSITIONS", product.propositions.size()));
        product.MakeTransitive();
        product.MakeReflexive();
        System.out.println("=========================================MADE REFLEXIVE");
        return product;
    }

    private boolean CheckPreOrder(Agent agent, Model model, ActionModel actionModel, State s, State t, ActionState sigma, ActionState tau){
        boolean value = false;
        for (Relation r: tau.relations){
            if (r.agent == agent && r.state_to == sigma){
                value = true;
                for (Relation r2: sigma.relations){
                    if (r2.agent == agent && r2.state_to == tau){
                        return Check2(agent, model, s, t);
                    }
                }
            }
        }
        if (value){
            for (Relation r: s.relations){
                if ((r.agent == agent && r.state_to==t)){
                    return true;
                }
            }
            for (Relation r: t.relations){
                if ((r.agent == agent && r.state_to==s)){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean Check2(Agent agent, Model model, State s, State t){
        for (Relation r: t.relations){
            if (r.agent == agent && r.state_to==s){
                return true;
            }
        }
        return false;
    }

    private boolean IsFinal(){
        Proposition evaded = model.GetTruthProposition();
        Proposition intervened = new Proposition("i");
        for (int i=0; i<n_agents; i++){
            evaded = model.GetConjunction(evaded, pEvade.get(i));
            intervened = model.GetDisjunction(intervened, pIntervene.get(i));
        }
        if (intervened.GetStates(model).contains(model.trueState)){
            this.intervened = true;
        }
        return model.GetDisjunction(evaded, intervened).GetStates(model).contains(model.trueState);
//        return (evaded.GetStates(model).contains(model.trueState));
    }


    public void Step(){
        switch (state){
            default:
                break;
            case INIT:
                InitModel();
                state = SimState.START;
                break;
            case START:
                EventStep();
                state = SimState.EVENT;
                break;
            case EVENT:
                ChooseActionStep();
                state = SimState.CHOOSE;
                if (IsFinal()){
                    state = SimState.FINAL;
                }
                break;
            case CHOOSE:
                InterpretationStep();
                state = SimState.REVISE;
                break;
            case REVISE:
                AlterBeliefsStep();
                state = SimState.CHOOSENEW;
                break;
            case CHOOSENEW:
                ChooseActionStep();
                state = SimState.REVISE;
                if (IsFinal()){
                    state = SimState.FINAL;
                }
        }
        buttonPanel.Update();
        situationPanel.Update();
        knowledgePanel.Update();
        simInfoPanel.Update();
        propositionsPanel.Update();
    }

    public void Reset(){
        state = SimState.INIT;
        System.out.println("reset");
        agents.clear();
        initialModel = null;
        eventModel = null;
        chooseActionModel = null;
        interpretationModel = null;
        finalModel = null;
        model = null;
        pObserve = null;
        pIntervene = null;
        pEvade = null;
        intervened = false;

        InitSim();
        buttonPanel.Update();
        situationPanel.Reset();
        knowledgePanel.Update();
        simInfoPanel.Update();
        propositionsPanel.Update();
    }

    public KnowledgePanel getKnowledgePanel(){
        return knowledgePanel;
    }

    public void setShowIntrospectiveBeliefs(boolean value){
        showIntrospectiveBeliefs = value;
        knowledgePanel.Update();
    }

    public boolean getShowIntrospectiveBeliefs(){
        return showIntrospectiveBeliefs;
    }

    public void setShowNegatedActionBeliefs(boolean value){
        showNegatedActionBeliefs = value;
        knowledgePanel.Update();
    }

    public boolean getShowNegatedActionBeliefs(){
        return showNegatedActionBeliefs;
    }

    public void setUseFriendship(boolean value){
        useFriendship = value;
        Reset();
    }

    public boolean getUseFriendship(){
        return useFriendship;
    }
}

package ai.mas;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class KripkePanel extends JPanel {

    Simulation sim;
    private static final String IMG_PATH = "src/images/kripke_example.png";

    public KripkePanel(Simulation sim){
        this.sim = sim;
        addFigure();
    }

    private void addFigure(){
        try {
            BufferedImage img = ImageIO.read(new File(IMG_PATH));
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            add(imgLabel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

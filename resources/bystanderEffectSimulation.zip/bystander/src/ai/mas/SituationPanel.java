package ai.mas;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

import javax.swing.JPanel;

public class SituationPanel extends JPanel {

    Simulation sim;
    private static final String IMG_PATH_DECREASE_BL = "/images/decrease_bl.png";
    private Image decrease_bl_img;
    private static final String IMG_PATH_INCREASE_BL = "/images/increase_bl.png";
    private Image increase_bl_img;
    private static final String IMG_PATH_DECREASE_RE = "/images/decrease_re.png";
    private Image decrease_re_img;
    private static final String IMG_PATH_INCREASE_GR = "/images/increase_gr.png";
    private Image increase_gr_img;
    private static final String IMG_PATH_TABLE = "/images/table.jpg";
    private Image table_img;
    private static final String IMG_PATH_AGENT = "/images/smiley.png";
    private Image agent_img;
    private static final String IMG_PATH_MEETING = "/images/meeting.png";
    private Image meeting_img;
    private static final String IMG_PATH_THOUGHT_BALLOON = "/images/thought_balloon.png";
    private Image thought_balloon_img;
    private static final String IMG_PATH_ACTION_BALLOON = "/images/action_balloon_filled.png";
    private Image action_balloon_img;


    private int window_width = 500;
    private int window_height = 300;

    private int delta_x_agent = 78;
    private int delta_y_agent = 145;
    private int size_agent = 50;

    private int active_agent;
    private boolean firm_is_fine = false;



    public SituationPanel(Simulation sim){
        this.sim = sim;
        firm_is_fine = true;
        active_agent = -1;

        decrease_bl_img = loadImage(IMG_PATH_DECREASE_BL);
        decrease_re_img = loadImage(IMG_PATH_DECREASE_RE);
        increase_bl_img = loadImage(IMG_PATH_INCREASE_BL);
        increase_gr_img = loadImage(IMG_PATH_INCREASE_GR);
        meeting_img = loadImage(IMG_PATH_MEETING);
        table_img = loadImage(IMG_PATH_TABLE);
        agent_img = loadImage(IMG_PATH_AGENT);
        thought_balloon_img = loadImage(IMG_PATH_THOUGHT_BALLOON);
        action_balloon_img = loadImage(IMG_PATH_ACTION_BALLOON);
        this.setOpaque(true);
        this.setBackground(Color.white);
        setPreferredSize(new Dimension(window_width, window_height));

//        Mouse Listener
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                active_agent = getAgent(e.getX(), e.getY());
                sim.getKnowledgePanel().Update();
                repaint();
            }
        });
    }

    private int getAgent(int x, int y){
        int selected_agent = active_agent;
        if (y > 75 && y < 75 + size_agent) {
            if (x > 177 && x < 177 + size_agent){
                selected_agent = 0;
            } else if (x > 177 + delta_x_agent && x < 177 + delta_x_agent + size_agent){
                selected_agent = 1;
            } else if (x > 177 + delta_x_agent * 2 && x < 177 + delta_x_agent * 2 + size_agent){
                selected_agent = 2;
            }
        } else if (y > 75 + delta_y_agent && y < 75 + delta_y_agent + size_agent) {
            if (x > 177 && x < 177 + size_agent){
                selected_agent = 3;
            } else if (x > 177 + delta_x_agent && x < 177 + delta_x_agent + size_agent){
                selected_agent = 4;
            } else if (x > 177 + delta_x_agent * 2 && x < 177 + delta_x_agent * 2 + size_agent){
                selected_agent = 5;
            }
        }
        if (selected_agent >= sim.agents.size()){
            selected_agent = active_agent;
        }
        return selected_agent;
    }

    private int[] getCoorFromAg(int agent){
        int coors[] = new int[2];
        if (agent == 0){
            coors[0] = 177;
            coors[1] = 75;
        } else if (agent == 1){
            coors[0] = 177 + delta_x_agent;
            coors[1] = 75;
        } else if (agent == 2){
            coors[0] = 177 + delta_x_agent * 2;
            coors[1] = 75;
        } else if (agent == 3){
            coors[0] = 177;
            coors[1] = 75 + delta_y_agent;
        } else if (agent == 4){
            coors[0] = 177 + delta_x_agent;
            coors[1] = 75 + delta_y_agent;
        } else if (agent == 5){
            coors[0] = 177 + delta_x_agent * 2;
            coors[1] = 75 + delta_y_agent;
        } else {
            System.err.println("Wrong Agent Chosen");
        }
        return coors;
    }

    private void draw_agent(Graphics g, int agent){
        int x = getCoorFromAg(agent)[0];
        int y = getCoorFromAg(agent)[1];
        g.drawImage(agent_img, x, y, size_agent, size_agent, null);
    }

    private void draw_actions(Graphics g){
        for (int a = 0; a < sim.n_agents; a++) {
            int x = getCoorFromAg(a)[0] + 20;
            int y = getCoorFromAg(a)[1] - 55;
            g.drawImage(action_balloon_img, x, y, size_agent, size_agent, null);
//            char action = sim.agents.get(agent).ChooseAction();
            char action = '0';
            if (sim.pObserve.get(a).GetStates(sim.model).contains(sim.model.trueState)){
                action = 'O';
            } else if (sim.pEvade.get(a).GetStates(sim.model).contains(sim.model.trueState)){
                action = 'E';
            } else if (sim.pIntervene.get(a).GetStates(sim.model).contains(sim.model.trueState)){
                action = 'I';
            }
            g.drawString(Character.toString(action), x+20, y+28);
        }
    }

    private void draw_beliefs(Graphics g){
        for (int a = 0; a < sim.n_agents; a++) {
            int x = getCoorFromAg(a)[0] - 10;
            int y = getCoorFromAg(a)[1] - 55;
            g.drawImage(thought_balloon_img, x, y, size_agent, size_agent, null);
            // check social belief first
            Agent agent = sim.agents.get(a);
            Proposition SBp = sim.model.GetSocialBelief(agent, sim.pEvent);
            Proposition SBnp = sim.model.GetSocialBelief(agent, sim.model.GetNegation(sim.pEvent));
            String thought;
            if (sim.state == Simulation.SimState.EVENT || sim.state== Simulation.SimState.CHOOSENEW) {
                boolean thinksP = false;
                if (SBnp.GetStates(sim.model).contains(sim.model.trueState)) {
                    thinksP = false;
                } else if (SBp.GetStates(sim.model).contains(sim.model.trueState)) {
                    thinksP = true;
                } else if (agent.Believes(sim.model, sim.model.trueState, sim.pEvent, true)) {
                    thinksP = true;
                } else if (agent.Believes(sim.model, sim.model.trueState, sim.pEvent, false)) {
                    thinksP = false;
                }
                thought = (thinksP ? sim.pEvent.name : "~" + sim.pEvent.name);
            } else {
                thought = "...";
            }
            g.drawString(thought, x+20, y+20);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(table_img, 60, 60, 440, 240, null);
        switch (sim.state){
            default:
                break;
            case INIT:
                break;
            case START:
                g.drawImage(increase_bl_img, 10, 10, 75, 75, null);
                break;
            case EVENT:
                g.drawImage(decrease_bl_img, 10, 10, 75, 75, null);
                draw_beliefs(g);
                break;
            case CHOOSE:
                g.drawImage(decrease_bl_img, 10, 10, 75, 75, null);
                draw_actions(g);
                break;
            case REVISE:
                g.drawImage(decrease_bl_img, 10, 10, 75, 75, null);
                draw_beliefs(g);
                break;
            case CHOOSENEW:
                g.drawImage(decrease_bl_img, 10, 10, 75, 75, null);
                draw_beliefs(g);
                break;
            case FINAL:
                if (sim.intervened){
                    g.drawImage(increase_gr_img, 10, 10, 75, 75, null);
                } else {
                    g.drawImage(decrease_re_img, 10, 10, 75, 75, null);
                }
                draw_actions(g);
                break;
        }
        for (int agent = 0; agent < sim.n_agents; agent++) {
            draw_agent(g, agent);
        }
//        draw_beliefs(g);
        g.setColor(Color.blue);
        if (active_agent!=-1) {
            g.drawOval(getCoorFromAg(active_agent)[0], getCoorFromAg(active_agent)[1], size_agent, size_agent);
        }
    }

    private Image loadImage(String path) {
        try {
            BufferedImage img = ImageIO.read(new File(getClass().getResource(path).toURI()));
            ImageIcon ii = new ImageIcon(img);
            return ii.getImage();
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void Update(){
//        active_agent = 0;
        active_agent = (active_agent==-1?0:active_agent);
        repaint();
    }

    public void Reset(){
        active_agent = -1;
        repaint();
    }

    public int getActive_agent(){
        return active_agent;
    }
}
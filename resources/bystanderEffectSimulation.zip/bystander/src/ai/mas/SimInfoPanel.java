package ai.mas;

import javax.swing.*;
import java.awt.*;

public class SimInfoPanel extends JPanel {

    Simulation sim;
    JLabel title;
    JTextArea descriptionPane;

    String evadedString = "All agents chose a new action under the influence of their new social beliefs. \n" +
            "\n" +
            "Since all agents evaded, the end condition is triggered. In this final condition the poorly performing strategy is " +
            "maintained because all agents are influenced by their social belief that no intervention is needed, even though all " +
            "agents individually believe that an intervention is needed.";
    String intervenedString = "All agents chose a new action under the influence of their new social beliefs. \n" +
            "\n" +
            "Since at least one agent intervened, the end condition is triggered. In this final condition, an intervention " +
            "happened, which means that at least one agent spoke out against the business strategy. The strategy can now be changed.";


    public SimInfoPanel(Simulation sim, Dimension dim){
        this.sim = sim;
        this.setPreferredSize(dim);
        title = new JLabel("Information");
        descriptionPane = new JTextArea();
        descriptionPane.setText(get_description(Simulation.SimState.INIT));
        descriptionPane.setOpaque(false);
        descriptionPane.setEditable(false);
        descriptionPane.setVisible(true);
        descriptionPane.setLineWrap(true);
        descriptionPane.setWrapStyleWord(true);
        descriptionPane.setPreferredSize(new Dimension(this.getPreferredSize().width-20,this.getPreferredSize().height-35));
        Font f = title.getFont();
        title.setFont(f.deriveFont(f.getStyle() | Font.BOLD));
        add(title);
        add(title);
        add(descriptionPane);
        Update();
    }

    private String get_description(Simulation.SimState step){
        String description = "No more descriptions...";
        switch (step){
            case INIT:
                description = "Welcome to the bystander effect simulator. This application illustrates how epistemic reasoning of agents can give rise to the bystander effect.\n" +
                        "\n" +
                        "The bystander effect occurs in social settings in which an event happens that requires an intervention. While the event is observed by several individuals, nobody intervenes due to erroneous reasoning about the beliefs of the other witnesses.\n" +
                        "\n" +
                        "The setting of this simulator is a firm, where several board members witness an event that renders the current business strategy inadequate, and which causes the firm to lose money. The agents are board members, who can intervene by objecting against the strategy.\n" +
                        "\n" +
                        "A friendship tie between two agents can be used to 'break' the bystander effect. When two agents have a friendship tie, both agents are aware of the beliefs of the other agent.";
                break;
            case START:
                description = String.format("The agents in this simulation are %s board members of a firm. In the initial situation the business strategy" +
                        " of the firm is successful, and the firm is making money.\n" +
                        "\n" +
                        "At some point in time however, an event might happen that causes the firm to lose money. This event can for example" +
                        " be an adjustment to the business strategy or a change in the market. When the event happens, an intervention is required," +
                        " which means that the business strategy should be changed. \n" +
                        "\n" +
                        "The event is denoted with p. In the current situation the firm is doing fine, so none of the agents has a reason" +
                        " to believe that an intervention is required.", sim.n_agents);
                break;
            case EVENT:
                description = String.format("The firm is now performing poorly due to the current business strategy.\n\n" +
                                "The %s board members privately believe the strategy should be changed, but have no information " +
                                "about the beliefs of other agents.\n\nDuring a board meeting, the question is asked whether anyone" +
                        " has an objection against the current strategy. Each board member can now choose between 3 actions:\n\n" +
                        "- Intervene: Speak out against the strategy\n" +
                        "- Evade: Do not speak out against the strategy\n" +
                        "- Observe: Wait for the reactions of other agents to make a decision \n\n" +
                        "The action chosen by each agent is determined by their current beliefs. " +
                        "The simulation is over when at least one agent has intervened, or when all agents have evaded.", sim.n_agents);
                break;
            case CHOOSE:
                description = "After all agents have chosen an action, the observing agents look at the reactions of other agents. \n" +
                        "\n" +
                        "Because the 'evade' and 'observe' actions are epistemically ambiguous for other agents, and the agents think that " +
                        "evading is more likely than observing, each action other than intervene will be interpreted as evading by the observing agents.  \n" +
                        "\n" +
                        "The epistemic ambiguity between the observe and evade actions can be broken by a friendship tie. In this case, both agents will " +
                        "have the correct belief about the action chosen by the other agent.";
                break;
            case REVISE:
                description = "The agents reason that other agents who evaded believe that the strategy should not be changed. Similarly, all agents that are " +
                        "believed to have observed, are assumed to believe that the strategy should be changed.\n" +
                        "\n" +
                        "In this step, the situation can arise where all agents privately believe that the strategy should change, and that all other agents believe " +
                        "the contrary. This situation is referred to as the 'state of pluralistic ignorance' that forms the basis of the bystander effect.";
                break;
            case CHOOSENEW:
                description = "The agents revise their beliefs in the light of the new information, using the following reasoning: 'If the majority of the other agents believes that no" +
                        " intervention is required, then that must mean that there is indeed no intervention required', and similarly: 'If the majority of the agents believes that an intervention is required, then that must mean that an intervention is indeed required'. \n\n" +
                        "This 'social belief' is indicated with a new belief operator SB_i(p).\n\n" +
                        "The agents will now choose a new action based on their revised beliefs.";
                break;
            case FINAL:
                description = (sim.intervened?intervenedString:evadedString);
                break;
        }
        return description;
    }

    private String get_title(Simulation.SimState step){
        String title = "Welcome";
        switch (step){
            case INIT:
                title = "Welcome";
                break;
            case START:
                title = "The initial situation";
                break;
            case EVENT:
                title = "A problem arises";
                break;
            case CHOOSE:
                title = "Looking for social proof";
                break;
            case REVISE:
                title = "Interpretation of social proof";
                break;
            case CHOOSENEW:
                title = "Interpretation of social proof";
                break;
            case FINAL:
                title = "Acting on the new beliefs";
                break;
        }
        return title;
    }

    public void Update(){
        descriptionPane.setText(get_description(sim.state));
        title.setText(get_title(sim.state));
//        title.setText("Information about the current state of the model. Step: " + sim.state);

    }
}

package ai.mas;

public class Belief {

    Proposition proposition;
    boolean valuation;
    boolean isSocialBelief;
    int order;
    Agent agent;
    Agent holder;

    public Belief(Agent holder, Proposition proposition, boolean valuation){
        this.holder = holder;
        this.proposition = proposition;
        this.valuation = valuation;
        this.order = 1;
    }

    public Belief(Agent holder, Proposition proposition, boolean valuation, boolean isSocialBelief){
        this(holder, proposition, valuation);
        this.isSocialBelief = true;
    }

    public Belief(Agent holder, Agent agent, Proposition proposition, boolean valuation){
        this.holder = holder;
        this.agent = agent;
        this.proposition = proposition;
        this.valuation = valuation;
        this.order = 2;
    }

    public String toString(){
        String sbStr = (isSocialBelief?"S":"");
        String valStr = (valuation?"":"~");
        if (order == 1){
            return String.format("%sB_%s( %s%s )", sbStr, holder.name, valStr, proposition.name);
        } else {
//            return (valuation? String.format("B_%s(%s)",agent.name, proposition.name) : String.format("B_%s(~%s)",agent.name, proposition.name));
            return String.format("B_%s( B_%s( %s%s ) )", holder.name, agent.name, valStr, proposition.name);
        }
    }
}

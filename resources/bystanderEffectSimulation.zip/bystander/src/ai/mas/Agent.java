package ai.mas;

import javax.swing.text.html.HTMLDocument;
import java.util.ArrayList;

import static ai.mas.Simulation.SimState.CHOOSENEW;
import static java.lang.System.exit;

public class Agent {

    AgentType agentType;
//    ArrayList<Relation> relations;
    String name;
//    Model model;
    Simulation sim;
    ArrayList<Belief> beliefs;
    ArrayList<Agent> friends;
    boolean influenced;

    public enum AgentType{
        FIRST_RESPONDER, CITY_DWELLER, HESITATOR
    }

    public Agent(String name, AgentType agentType, Simulation sim){
        this.name = name;
        this.agentType = agentType;
        this.sim = sim;
        this.beliefs = new ArrayList<>();
        this.friends = new ArrayList<>();
        influenced = false;
    }


    public boolean Knows(Model model, State state, Proposition p){
        return(p.GetStates(model).containsAll(GetInformationCell(model, state)));
    }

    public boolean Believes(Model model, State state, Proposition p){
        return Believes(model, state, p, true);
    }

    public boolean Believes(Model model, State state, Proposition p, boolean valuation){
        ArrayList<State> p_states;
        if (valuation) {
            p_states = p.GetStates(model);
        } else {
            p_states = new ArrayList<State>(model.states);
            p_states.removeAll(p.GetStates(model));
        }
        return(p_states.containsAll(GetPlausibilityCell(model, state)));
    }

    public boolean Believes2ndOrder(Model model, State state, Agent agent, Proposition p, boolean valuation){
        for (Relation r: state.relations){
            if (r.agent == this){
                if (!agent.Believes(model, r.state_to, p, valuation)){
                    return false;
                }
            }
        }
        return true;
    }

//    public ArrayList<String> ListBeliefs(Model model, State state){ // TODO: make belief object that holds proposition, order and agent
//        ArrayList<String> beliefs = new ArrayList<>();
//        System.out.println(String.format("\nBeliefs of agent %s in state %s:", name, state.name));
//        for (Proposition p: model.propositions){
//            if (Believes(model, state,p,true)){
//                System.out.println(p.name);
//                beliefs.add(p.name);
//            }
//            if (Believes(model, state,p,false)){
//                System.out.println(String.format("~%s",p.name));
//                beliefs.add(String.format("~%s",p.name));
//            }
//        }
//        for (Agent agent: sim.agents){
//            for (Proposition p: model.propositions){
//                ArrayList<State> pcell = GetPlausibilityCell(model, state);
//                for (State bs: pcell) {
//                    if (Believes2ndOrder(model, bs, agent, p, true)) {
//                        System.out.println(String.format("B_%s(%s)", agent.name, p.name));
//                        beliefs.add(String.format("B_%s(%s)", agent.name, p.name));
//                    }
//                    if (Believes2ndOrder(model, bs, agent, p, false)) {
//                        System.out.println(String.format("B_%s(~%s)", agent.name, p.name));
//                        beliefs.add(String.format("B_%s(~%s)", agent.name, p.name));
//                    }
//                }
//            }
//        }
//        return beliefs;
//    }
        public ArrayList<Belief> ListBeliefs(Model model, State state){
        UpdateBeliefs(model, state);
        return beliefs;
    }


    public void UpdateBeliefs(Model model, State state){
        beliefs.clear();
        for (Proposition p: model.propositions){
            if (Believes(model, state, p, true)){
                beliefs.add(new Belief(this, p, true));
            }
            if (sim.pEvent == p || sim.getShowNegatedActionBeliefs()) {
                if (Believes(model, state, p, false)) {
                    beliefs.add(new Belief(this, p, false));
                }
            }
        }
        if (sim.state == CHOOSENEW){
            Proposition SBnp = model.GetSocialBelief(this, model.GetNegation(sim.pEvent));
            Proposition SBp = model.GetSocialBelief(this, sim.pEvent);
//            if (Believes(model, state, SBnp, true)){
            if (SBnp.GetStates(model).contains(state)){
                beliefs.add(new Belief(this, sim.pEvent, false, true));
            }
//            if (Believes(model, state, SBp, true)){
            if (SBp.GetStates(model).contains(state)){
//                System.out.println("found");
//                exit(0);
                beliefs.add(new Belief(this, sim.pEvent, true, true));
            }
        }
        ArrayList<State> pCell = GetPlausibilityCell(model, state);
        for (Agent agent: sim.agents){
            if (agent != this || sim.getShowIntrospectiveBeliefs()) {
                for (Proposition p : model.propositions) {
                    for (State bs : pCell) {
                        if (Believes2ndOrder(model, bs, agent, p, true)) {
                            Belief b = new Belief(this, agent, p, true);
                            if (!HasBelief(b)) {
                                beliefs.add(new Belief(this, agent, p, true));
                            }
                        }
                        if (sim.pEvent == p || sim.getShowNegatedActionBeliefs()) {
                            if (Believes2ndOrder(model, bs, agent, p, false)) {
                                Belief b = new Belief(this, agent, p, false);
                                if (!HasBelief(b)) {
                                    beliefs.add(new Belief(this, agent, p, false));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void AddBelief(Model model, State state, Proposition p, boolean valuation){
        if (Believes(model, state, p, valuation)){
            Belief b = new Belief(this, p, valuation);
            if (!HasBelief(b)){
                beliefs.add(b);
            }
        }
    }

    private boolean HasBelief(Belief b){
        for (Belief belief: beliefs){
            if (belief.agent==b.agent && belief.proposition==b.proposition && belief.valuation==b.valuation){
                return true;
            }
        }
        return false;
    }

    public ArrayList<State> GetInformationCell(Model model, State state){
        ArrayList<State> informationCell = new ArrayList<>();
        for (Relation r: state.relations){
            if (r.agent == this){
                informationCell.add(r.state_to);
            }
        }
        for (State s2: model.states){
            for (Relation r2: s2.relations){
                if (r2.agent == this && r2.state_to == state){
                    informationCell.add(s2);
                }
            }
        }
        return informationCell;
    }

    public ArrayList<State> GetPlausibilityCell(Model model, State state){
        ArrayList<State> informationCell = GetInformationCell(model, state);
        ArrayList<State> plausibilityCell = new ArrayList<>();
        for (State t: informationCell){
            if (IsPlausible(model, informationCell, t)){
                plausibilityCell.add(t);
            }
        }
        return plausibilityCell;
    }

    private boolean IsPlausible(Model model, ArrayList<State> informationCell, State t){
        for (State s: informationCell){
            boolean valid = false;
            for (Relation r: s.relations){
                if (r.agent== this && r.state_to == t){
                    valid = true;
                }
            }
            if (!valid){
                return false;
            }
        }
        return true;
    }

    public char ChooseAction(){
        switch (agentType){
            case FIRST_RESPONDER:
                return FirstResponder();
            case CITY_DWELLER:
                return CityDweller();
            case HESITATOR:
                return (influenced?InfluencedHesitator():Hesitator());
        }
        return 'X';
    }

    private char CityDweller(){
        return 'E';
    }

    private char Hesitator(){
        Proposition SBp = sim.model.GetSocialBelief(this, sim.pEvent);
        if (Knows(sim.model, sim.model.trueState, sim.pEvent)) {
            // intervene
            return 'I';
        } else if (Believes(sim.model, sim.model.trueState, SBp, false)
                || Believes(sim.model, sim.model.trueState, sim.pEvent, false)){
            // evade
            return 'E';
        } else if (Believes(sim.model, sim.model.trueState, sim.pEvent)) {
            //observe
            influenced = true;
            return 'O';
        }
        return 'O';
    }

    private char InfluencedHesitator(){
        Proposition SBp = sim.model.GetSocialBelief(this, sim.pEvent);
        Proposition SBnp = sim.model.GetSocialBelief(this, sim.model.GetNegation(sim.pEvent));
        boolean hasSocialBelief = SBp.GetStates(sim.model).contains(sim.model.trueState);
        boolean hasNegSocialBelief = SBnp.GetStates(sim.model).contains(sim.model.trueState);
        if (Knows(sim.model, sim.model.trueState, sim.pEvent) || hasSocialBelief) {
            // intervene
            return 'I';
        } else if (!Knows(sim.model, sim.model.trueState, sim.pEvent) && !(hasNegSocialBelief || hasSocialBelief)){
            return 'O';
        } else {
            return 'E';
        }
    }

    private char FirstResponder(){
        if (Believes(sim.model, sim.model.trueState, sim.pEvent)){
            return 'I';
        } else if (Believes(sim.model, sim.model.trueState, sim.model.GetNegation(sim.pEvent))){
            return 'E';
        }
        return 'X';
    }

    @Override
    public String toString() {
        return name;
    }
}

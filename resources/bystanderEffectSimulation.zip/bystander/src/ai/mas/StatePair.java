package ai.mas;

public class StatePair {

    ActionState actionState1;
    ActionState actionState2;

    public StatePair(ActionState actionState1, ActionState actionState2){
        this.actionState1 = actionState1;
        this.actionState2 = actionState2;
    }
}
